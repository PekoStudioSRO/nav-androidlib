package cz.pekostudio.nav

/**
 * Created by Lukas Urbanek on 28/04/2020.
 */
class BaseActivity : {

}